export default window.CodeMirror;
